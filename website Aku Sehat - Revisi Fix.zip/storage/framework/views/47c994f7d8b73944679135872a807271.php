<?php $__env->startSection('title', 'Data Kesehatan'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header Section -->
    <div class="bg-white p-4 md:p-6 rounded-lg shadow-sm">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-stethoscope text-[#1b5e20] text-xl"></i>
                </div>
                <div>
                    <h2 class="text-2xl font-bold text-[#1a472a]">Data Kesehatan</h2>
                    <p class="text-[#388e3c]">Manajemen data kesehatan member</p>
                </div>
            </div>   
            <div class="flex flex-col sm:flex-row gap-2">
                <!-- Export Buttons -->
                <div class="flex gap-2">
                    <a href="<?php echo e(route('admin.kesehatan.export.excel')); ?>" 
                       class="bg-[#4caf50] hover:bg-[#388e3c] text-white px-4 py-2 rounded-md text-sm font-medium transition-colors flex items-center justify-center shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200">
                        <i class="fas fa-file-excel mr-2"></i>
                        Export Excel
                    </a>
                    <a href="<?php echo e(route('admin.kesehatan.export.pdf')); ?>" 
                       class="bg-[#f44336] hover:bg-[#d32f2f] text-white px-4 py-2 rounded-md text-sm font-medium transition-colors flex items-center justify-center shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200">
                        <i class="fas fa-file-pdf mr-2"></i>
                        Export PDF
                    </a>
                </div>
                <!-- Tambah Data Button -->
                <a href="<?php echo e(route('admin.kesehatan.create')); ?>" 
                   class="bg-[#2e7d32] hover:bg-[#1b5e20] text-white px-4 py-2 rounded-md text-sm font-medium transition-colors flex items-center justify-center shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200">
                    <i class="fas fa-plus mr-2"></i>
                    Tambah Data
                </a>
            </div>
        </div>
    </div>

    <!-- Table Section -->
    <div class="bg-white shadow-sm rounded-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-[#e8f5e9]">
                    <tr>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider">
                            Member
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider hidden md:table-cell">
                            Divisi
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider">
                            Tanggal
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider hidden sm:table-cell">
                            BB/TB
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider hidden lg:table-cell">
                            IMT
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider">
                            Status BMI
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider">
                            Status Tekanan Darah
                        </th>
                        <th class="px-4 md:px-6 py-3 text-center text-xs font-medium text-[#1b5e20] uppercase tracking-wider">
                            Aksi
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $kesehatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-[#f1f8e9] transition-colors duration-150">
                            <td class="px-4 md:px-6 py-4">
                                <div class="text-sm font-medium text-gray-900"><?php echo e($item->user->nama); ?></div>
                                <div class="text-sm text-gray-500"><?php echo e($item->user->nomor_induk); ?></div>
                                <div class="text-sm text-gray-500 md:hidden mt-2">
                                    Divisi: <?php echo e($item->user->divisi->divisi_name); ?>

                                </div>
                                <div class="text-sm text-gray-500 sm:hidden mt-2">
                                    BB/TB: <?php echo e($item->bb); ?>kg / <?php echo e($item->tb); ?>cm
                                </div>
                                <div class="text-sm text-gray-500 lg:hidden mt-2">
                                    IMT: <?php echo e($item->imt); ?>

                                </div>
                            </td>
                            <td class="px-4 md:px-6 py-4 whitespace-nowrap text-sm text-gray-900 hidden md:table-cell">
                                <?php echo e($item->user->divisi->divisi_name); ?>

                            </td>
                            <td class="px-4 md:px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?php echo e($item->tgl->format('d/m/Y')); ?>

                            </td>
                            <td class="px-4 md:px-6 py-4 whitespace-nowrap text-sm text-gray-900 hidden sm:table-cell">
                                <?php echo e($item->bb); ?>kg / <?php echo e($item->tb); ?>cm
                            </td>
                            <td class="px-4 md:px-6 py-4 whitespace-nowrap text-sm text-gray-900 hidden lg:table-cell">
                                <?php echo e($item->imt); ?>

                            </td>
                            <td class="px-4 md:px-6 py-4 whitespace-nowrap">
                                <?php
                                    $statusClass = match($item->status) {
                                        'Underweight' => 'bg-[#fff9c4] text-[#f57f17]',
                                        'Normal' => 'bg-[#c8e6c9] text-[#1b5e20]',
                                        'Overweight' => 'bg-[#ffe0b2] text-[#ef6c00]',
                                        'Obesitas Level 1' => 'bg-[#ffcdd2] text-[#c62828]',
                                        'Obesitas Level 2' => 'bg-[#f44336] text-white',
                                        'Obesitas Level 3' => 'bg-[#b71c1c] text-white',
                                        default => 'bg-gray-100 text-gray-800'
                                    };
                                ?>
                                <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($statusClass); ?>">
                                    <?php echo e($item->status); ?>

                                </span>
                            </td>

                            <td class="px-4 md:px-6 py-4 whitespace-nowrap">
                                <?php
                                    $statusClass = match($item->status_darah) {
                                        'Hipotensi' => 'bg-[#bbdefb] text-[#0d47a1]',
                                        'Normal' => 'bg-[#c8e6c9] text-[#1b5e20]',
                                        'Elevasi' => 'bg-[#fff9c4] text-[#f57f17]',
                                        'Hipertensi Tahap 1' => 'bg-[#ffe0b2] text-[#ef6c00]',
                                        'Hipertensi Tahap 2' => 'bg-[#ffcdd2] text-[#c62828]',
                                        'Krisis' => 'bg-[#b71c1c] text-white',
                                        default => 'bg-gray-100 text-gray-800'
                                    };
                                ?>
                                <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($statusClass); ?>">
                                    <?php echo e($item->status_darah); ?>

                                </span>
                            </td>
                            <td class="px-4 md:px-6 py-4 text-base whitespace-nowrap font-medium">
                                <div class="flex items-center justify-center text-base">
                                    <a href="<?php echo e(route('admin.kesehatan.edit', $item->id_kesehatan)); ?>" 
                                       class="text-[#2e7d32] hover:text-[#1b5e20] p-1 transition-colors duration-200"
                                       title="Edit">
                                        <i class="fas fa-edit text-lg"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.kesehatan.destroy', $item->id_kesehatan)); ?>" 
                                          method="POST" class="inline"
                                          onsubmit="return confirm('Yakin ingin menghapus data kesehatan ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-[#d32f2f] hover:text-[#b71c1c] p-1 transition-colors duration-200"
                                                title="Hapus">
                                            <i class="fas fa-trash text-lg"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="px-6 py-8 text-center">
                                <div class="flex flex-col items-center justify-center text-gray-400">
                                    <i class="fas fa-stethoscope text-4xl mb-3"></i>
                                    <p class="text-lg font-medium">Tidak ada data kesehatan</p>
                                    <p class="text-sm mt-1">Klik "Tambah Data" untuk menambahkan data baru</p>
                                    <a href="<?php echo e(route('admin.kesehatan.create')); ?>" 
                                       class="mt-3 inline-flex items-center bg-[#2e7d32] hover:bg-[#1b5e20] text-white px-4 py-2 rounded-md text-sm font-medium transition-colors">
                                        <i class="fas fa-plus mr-2"></i>
                                        Tambah Data Kesehatan
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Custom Pagination -->
        <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between px-6 py-4 bg-[#f9fafb] border-t border-gray-200"">
            <div>
                <p class="text-sm text-gray-700 ">
                    Showing <span class="font-medium"><?php echo e($kesehatan->firstItem()); ?></span>
                    to <span class="font-medium"><?php echo e($kesehatan->lastItem()); ?></span>
                    of <span class="font-medium"><?php echo e($kesehatan->total()); ?></span> results
                </p>
            </div>
            <div>
                <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                    
                    <?php if($kesehatan->onFirstPage()): ?>
                        <span
                            class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300  bg-gray-100  text-sm font-medium text-gray-500 dark:text-gray-400">
                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                                viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                                    clip-rule="evenodd" />
                            </svg>
                        </span>
                    <?php else: ?>
                        <a href="<?php echo e($kesehatan->previousPageUrl()); ?>"
                            class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300  bg-white  text-sm font-medium text-gray-500  hover:bg-gray-50 ">
                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                                viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                                    clip-rule="evenodd" />
                            </svg>
                        </a>
                    <?php endif; ?>

                    
                    <?php
                        $currentPage = $kesehatan->currentPage();
                        $lastPage = $kesehatan->lastPage();
                        $start = max($currentPage - 2, 1);
                        $end = min($currentPage + 2, $lastPage);
                    ?>

                    
                    <?php if($start > 1): ?>
                        <a href="<?php echo e($kesehatan->url(1)); ?>"
                            class="relative inline-flex items-center px-4 py-2 border border-gray-300  text-sm font-medium <?php echo e($currentPage == 1 ? 'bg-[#2e7d32] text-white' : 'bg-white  text-gray-500  hover:bg-gray-50 '); ?>">
                            1
                        </a>
                        <?php if($start > 2): ?>
                            <span
                                class="relative inline-flex items-center px-4 py-2 border border-gray-300  bg-gray-100  text-sm font-medium text-gray-500 dark:text-gray-400">…</span>
                        <?php endif; ?>
                    <?php endif; ?>

                    
                    <?php for($page = $start; $page <= $end; $page++): ?>
                        <?php if($page == $currentPage): ?>
                            <span
                                class="z-10 bg-success-50 dark:bg-[#1b5e20] border-[#2e7d32] text-[#1b5e20] dark:text-white relative inline-flex items-center px-4 py-2 border text-sm font-medium">
                                <?php echo e($page); ?>

                            </span>
                        <?php else: ?>
                            <a href="<?php echo e($kesehatan->url($page)); ?>"
                                class="bg-white  border-gray-300  text-gray-500  hover:bg-gray-50  relative inline-flex items-center px-4 py-2 border text-sm font-medium">
                                <?php echo e($page); ?>

                            </a>
                        <?php endif; ?>
                    <?php endfor; ?>

                    
                    <?php if($end < $lastPage): ?>
                        <?php if($end < $lastPage - 1): ?>
                            <span
                                class="relative inline-flex items-center px-4 py-2 border border-gray-300  bg-gray-100  text-sm font-medium text-gray-500 dark:text-gray-400">…</span>
                        <?php endif; ?>
                        <a href="<?php echo e($kesehatan->url($lastPage)); ?>"
                            class="relative inline-flex items-center px-4 py-2 border border-gray-300  text-sm font-medium <?php echo e($currentPage == $lastPage ? 'bg-[#2e7d32] text-white' : 'bg-white  text-gray-500  hover:bg-gray-50 '); ?>">
                            <?php echo e($lastPage); ?>

                        </a>
                    <?php endif; ?>

                    
                    <?php if($kesehatan->hasMorePages()): ?>
                        <a href="<?php echo e($kesehatan->nextPageUrl()); ?>"
                            class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300  bg-white  text-sm font-medium text-gray-500  hover:bg-gray-50 ">
                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                                viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                    clip-rule="evenodd" />
                            </svg>
                        </a>
                    <?php else: ?>
                        <span
                            class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300  bg-gray-100  text-sm font-medium text-gray-500 dark:text-gray-400">
                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                                viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                    clip-rule="evenodd" />
                            </svg>
                        </span>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\VS Code\Jurnal\versifix\AkuSehat\resources\views/admin/kesehatan/index.blade.php ENDPATH**/ ?>