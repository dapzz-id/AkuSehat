<?php $__env->startSection('title', 'Data HB'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header -->
    <div class="bg-white p-4 md:p-6 rounded-lg shadow-sm">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-tint text-[#1b5e20] text-xl"></i>
                </div>
                <div>
                    <h2 class="text-2xl font-bold text-[#1a472a]">Data Hemoglobin (HB)</h2>
                    <p class="text-[#388e3c]">Manajemen data hemoglobin siswa</p>
                </div>
            </div>
            <div class="flex flex-col sm:flex-row gap-2">
                <!-- Export Buttons -->
                <div class="flex gap-2">
                    <a href="<?php echo e(route('admin.hb.export.excel')); ?>" 
                       class="bg-[#4caf50] hover:bg-[#388e3c] text-white px-4 py-2 rounded-md text-sm font-medium transition-colors flex items-center justify-center shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200">
                        <i class="fas fa-file-excel mr-2"></i>
                        Export Excel
                    </a>
                    <a href="<?php echo e(route('admin.hb.export.pdf')); ?>" 
                       class="bg-[#f44336] hover:bg-[#d32f2f] text-white px-4 py-2 rounded-md text-sm font-medium transition-colors flex items-center justify-center shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200">
                        <i class="fas fa-file-pdf mr-2"></i>
                        Export PDF
                    </a>
                </div>
                <!-- Tambah Data Button -->
                <a href="<?php echo e(route('admin.hb.create')); ?>" 
                   class="bg-[#2e7d32] hover:bg-[#1b5e20] text-white px-4 py-2 rounded-md text-sm font-medium transition-colors flex items-center justify-center shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200">
                    <i class="fas fa-plus mr-2"></i>
                    Tambah Data HB
                </a>
            </div>
        </div>
    </div>

    <!-- Table Card -->
    <div class="bg-white shadow-sm rounded-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-[#e8f5e9]">
                    <tr>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider">
                            Siswa
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider hidden md:table-cell">
                            Divisi
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider">
                            Tanggal
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider">
                            HB (g/dL)
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider">
                            Status
                        </th>
                        <th class="px-4 md:px-6 py-3 text-center text-xs font-medium text-[#1b5e20] uppercase tracking-wider">
                            Aksi
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $hb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-[#f1f8e9] transition-colors duration-150">
                            <!-- Siswa -->
                            <td class="px-4 md:px-6 py-4">
                                <div class="font-medium text-gray-900"><?php echo e($item->user->nama); ?></div>
                                <div class="text-gray-500 text-xs"><?php echo e($item->user->nomor_induk); ?> (<?php echo e($item->user->jk === 'L' ? 'L' : 'P'); ?>)</div>
                                <div class="text-sm text-gray-500 md:hidden mt-1">
                                    Divisi: <?php echo e($item->divisi->divisi_name); ?>

                                </div>
                                <div class="text-sm text-gray-500 lg:hidden mt-1">
                                    Pesan: <?php echo e(Str::limit($item->pesan, 30)); ?>

                                </div>
                            </td>
                            <!-- Divisi -->
                            <td class="px-4 md:px-6 py-4 text-gray-700 hidden md:table-cell">
                                <?php echo e($item->divisi->divisi_name); ?>

                            </td>
                            <!-- Tanggal -->
                            <td class="px-4 md:px-6 py-4 text-gray-700">
                                <?php echo e($item->tgl->format('d/m/Y')); ?>

                            </td>
                            <!-- HB -->
                            <td class="px-4 md:px-6 py-4 font-semibold text-gray-900">
                                <?php echo e($item->hb); ?>

                            </td>
                            <!-- Status -->
                            <td class="px-4 md:px-6 py-4">
                                <?php
                                    $statusClass = match($item->status) {
                                        'Normal' => 'bg-[#c8e6c9] text-[#1b5e20]',
                                        'Anemia' => 'bg-[#ffcdd2] text-[#c62828]',
                                        'Tinggi' => 'bg-[#ffe0b2] text-[#ef6c00]',
                                        default => 'bg-gray-100 text-gray-800'
                                    };
                                ?>
                                <span class="px-2 py-1 inline-flex text-xs font-semibold rounded-full <?php echo e($statusClass); ?>">
                                    <?php echo e($item->status); ?>

                                </span>
                            </td>
                            <!-- Pesan -->
                            
                            <!-- Aksi -->
                            <td class="px-4 md:px-6 py-4">
                                <div class="flex items-center justify-center text-base">
                                    <a href="<?php echo e(route('admin.hb.edit', $item->id_hb)); ?>" 
                                       class="text-[#2e7d32] hover:text-[#1b5e20] transition-colors duration-200 p-1 rounded-full hover:bg-green-50"
                                       title="Edit">
                                        <i class="fas fa-edit text-lg"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.hb.destroy', $item->id_hb)); ?>" method="POST" 
                                          onsubmit="return confirm('Yakin ingin menghapus data HB ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" 
                                                class="text-[#d32f2f] hover:text-[#b71c1c] transition-colors duration-200 p-1 rounded-full hover:bg-red-50"
                                                title="Hapus">
                                            <i class="fas fa-trash text-lg"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="px-6 py-8 text-center">
                                <div class="flex flex-col items-center justify-center text-gray-400">
                                    <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-3">
                                        <i class="fas fa-tint text-red-300 text-2xl"></i>
                                    </div>
                                    <p class="text-lg font-medium">Tidak ada data HB</p>
                                    <p class="text-sm mt-1">Klik "Tambah Data HB" untuk menambahkan data baru</p>
                                    <a href="<?php echo e(route('admin.hb.create')); ?>" 
                                       class="mt-3 inline-flex items-center bg-[#2e7d32] hover:bg-[#1b5e20] text-white px-4 py-2 rounded-md text-sm font-medium transition-colors">
                                        <i class="fas fa-plus mr-2"></i>
                                        Tambah Data HB
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Custom Pagination -->
        <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between px-6 py-4 bg-[#f9fafb] border-t border-gray-200"">
            <div>
                <p class="text-sm text-gray-700 ">
                    Showing <span class="font-medium"><?php echo e($hb->firstItem()); ?></span>
                    to <span class="font-medium"><?php echo e($hb->lastItem()); ?></span>
                    of <span class="font-medium"><?php echo e($hb->total()); ?></span> results
                </p>
            </div>
            <div>
                <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                    
                    <?php if($hb->onFirstPage()): ?>
                        <span
                            class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300  bg-gray-100  text-sm font-medium text-gray-500 dark:text-gray-400">
                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                                viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                                    clip-rule="evenodd" />
                            </svg>
                        </span>
                    <?php else: ?>
                        <a href="<?php echo e($hb->previousPageUrl()); ?>"
                            class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300  bg-white  text-sm font-medium text-gray-500  hover:bg-gray-50 ">
                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                                viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                                    clip-rule="evenodd" />
                            </svg>
                        </a>
                    <?php endif; ?>

                    
                    <?php
                        $currentPage = $hb->currentPage();
                        $lastPage = $hb->lastPage();
                        $start = max($currentPage - 2, 1);
                        $end = min($currentPage + 2, $lastPage);
                    ?>

                    
                    <?php if($start > 1): ?>
                        <a href="<?php echo e($hb->url(1)); ?>"
                            class="relative inline-flex items-center px-4 py-2 border border-gray-300  text-sm font-medium <?php echo e($currentPage == 1 ? 'bg-[#2e7d32] text-white' : 'bg-white  text-gray-500  hover:bg-gray-50 '); ?>">
                            1
                        </a>
                        <?php if($start > 2): ?>
                            <span
                                class="relative inline-flex items-center px-4 py-2 border border-gray-300  bg-gray-100  text-sm font-medium text-gray-500 dark:text-gray-400">…</span>
                        <?php endif; ?>
                    <?php endif; ?>

                    
                    <?php for($page = $start; $page <= $end; $page++): ?>
                        <?php if($page == $currentPage): ?>
                            <span
                                class="z-10 bg-success-50 dark:bg-[#1b5e20] border-[#2e7d32] text-[#2e7d32] dark:text-white relative inline-flex items-center px-4 py-2 border text-sm font-medium">
                                <?php echo e($page); ?>

                            </span>
                        <?php else: ?>
                            <a href="<?php echo e($hb->url($page)); ?>"
                                class="bg-white  border-gray-300  text-gray-500  hover:bg-gray-50  relative inline-flex items-center px-4 py-2 border text-sm font-medium">
                                <?php echo e($page); ?>

                            </a>
                        <?php endif; ?>
                    <?php endfor; ?>

                    
                    <?php if($end < $lastPage): ?>
                        <?php if($end < $lastPage - 1): ?>
                            <span
                                class="relative inline-flex items-center px-4 py-2 border border-gray-300  bg-gray-100  text-sm font-medium text-gray-500 dark:text-gray-400">…</span>
                        <?php endif; ?>
                        <a href="<?php echo e($hb->url($lastPage)); ?>"
                            class="relative inline-flex items-center px-4 py-2 border border-gray-300  text-sm font-medium <?php echo e($currentPage == $lastPage ? 'bg-[#2e7d32] text-white' : 'bg-white  text-gray-500  hover:bg-gray-50 '); ?>">
                            <?php echo e($lastPage); ?>

                        </a>
                    <?php endif; ?>

                    
                    <?php if($hb->hasMorePages()): ?>
                        <a href="<?php echo e($hb->nextPageUrl()); ?>"
                            class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300  bg-white  text-sm font-medium text-gray-500  hover:bg-gray-50 ">
                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                                viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                    clip-rule="evenodd" />
                            </svg>
                        </a>
                    <?php else: ?>
                        <span
                            class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300  bg-gray-100  text-sm font-medium text-gray-500 dark:text-gray-400">
                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                                viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                    clip-rule="evenodd" />
                            </svg>
                        </span>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\VS Code\Jurnal\versifix\AkuSehat\resources\views/admin/hb/index.blade.php ENDPATH**/ ?>