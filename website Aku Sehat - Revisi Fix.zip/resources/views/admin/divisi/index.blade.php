@extends('layouts.app')
@section('title', 'Data Divisi')
@section('content')
<div class="space-y-6">
    <!-- Header -->
    <div class="bg-white p-4 md:p-6 rounded-lg shadow-sm border border-gray-100">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-school text-[#1b5e20] text-xl"></i>
                </div>
                <div>
                    <h2 class="text-2xl font-bold text-[#1a472a]">Data Divisi</h2>
                    <p class="text-[#388e3c]">Manajemen data divisi</p>
                </div>
            </div>
            <button onclick="openModal()"
                    class="bg-[#2e7d32] hover:bg-[#1b5e20] text-white px-4 py-2 rounded-md text-sm font-medium transition-colors flex items-center justify-center shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200">
                <i class="fas fa-plus"></i>
                <span class="ml-2">Tambah Divisi</span>
            </button>
        </div>
    </div>
    <!-- Statistics Overview -->
    <div class="grid grid-cols-1 grid-cols-2 gap-4 md:gap-6">
        <div class="bg-white p-4 md:p-6 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div class="flex items-center">
                <div class="w-10 h-10 md:w-12 md:h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-school text-green-600 text-lg md:text-xl"></i>
                </div>
                <div class="ml-3 md:ml-4">
                    <p class="text-xs md:text-sm font-medium text-gray-600">Total Divisi</p>
                    <p class="text-xl md:text-2xl font-semibold text-gray-900">{{ $divisi->total() }}</p>
                </div>
            </div>
        </div>
        <div class="bg-white p-4 md:p-6 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div class="flex items-center">
                <div class="w-10 h-10 md:w-12 md:h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-users text-blue-600 text-lg md:text-xl"></i>
                </div>
                <div class="ml-3 md:ml-4">
                    <p class="text-xs md:text-sm font-medium text-gray-600">Total Users</p>
                    <p class="text-xl md:text-2xl font-semibold text-gray-900">{{ $divisi->sum('jumlah_member') }}</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Table Section -->
    <div class="bg-white shadow-sm rounded-lg overflow-hidden border border-gray-100">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-[#e8f5e9]">
                    <tr>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider">
                            Nama Divisi
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider">
                            Warna Cover
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider hidden md:table-cell">
                            Jumlah Users
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider hidden lg:table-cell">
                            Data Kesehatan
                        </th>
                        <th class="px-4 md:px-6 py-3 text-left text-xs font-medium text-[#1b5e20] uppercase tracking-wider hidden xl:table-cell">
                            Tanggal Dibuat
                        </th>
                        <th class="px-4 md:px-6 py-3 text-center text-xs font-medium text-[#1b5e20] uppercase tracking-wider">
                            Aksi
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @forelse($divisi as $item)
                        <tr class="hover:bg-[#f1f8e9] transition-colors duration-150">
                            <td class="px-4 md:px-6 py-4">
                                <div class="text-sm font-medium text-gray-900">{{ $item->divisi_name }}</div>
                                <div class="text-xs text-gray-500 md:hidden mt-1">
                                    Users: {{ $item->jumlah_member }}
                                </div>
                                <div class="text-xs text-gray-500 lg:hidden mt-1">
                                    Kesehatan: {{ $item->count_kesehatan }} data
                                </div>
                                <div class="text-xs text-gray-500 xl:hidden mt-1">
                                    Dibuat: {{ $item->created_at->format('d/m/Y') }}
                                </div>
                            </td>
                            <td class="px-4 md:px-6 py-4 text-sm text-gray-900">
                                <div class="flex items-center gap-2">
                                    <div class="w-6 h-6 rounded-md" style="background-color: {{ $item->color_cover }};"></div>
                                    <span class="uppercase">{{ $item->color_cover }}</span>
                                </div>
                            </td>
                            <td class="px-4 md:px-6 py-4 text-sm text-gray-900 hidden md:table-cell">
                                <div class="flex items-center">
                                    <i class="fas fa-users text-gray-400 mr-2"></i>
                                    {{ $item->jumlah_member }} users
                                </div>
                            </td>
                            <td class="px-4 md:px-6 py-4 text-sm text-gray-900 hidden lg:table-cell">
                                <div class="flex items-center">
                                    <i class="fas fa-heartbeat text-gray-400 mr-2"></i>
                                    {{ $item->count_kesehatan }} data
                                </div>
                            </td>
                            <td class="px-4 md:px-6 py-4 text-sm text-gray-500 hidden xl:table-cell">
                                {{ $item->created_at->format('d/m/Y') }}
                            </td>
                            <td class="px-4 md:px-6 py-4">
                                <div class="flex items-center justify-center text-base gap-2">
                                    <button onclick="editDivisi({{ json_encode($item) }})"
                                            class="text-[#2e7d32] hover:text-[#1b5e20] p-2 rounded-full hover:bg-green-50 transition-colors" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="{{ route('admin.users.index') }}?divisi={{ $item->id }}"
                                       class="text-[#0288d1] hover:text-[#01579b] p-2 rounded-full hover:bg-blue-50 transition-colors" title="Lihat Users">
                                        <i class="fas fa-users"></i>
                                    </a>
                                    <form action="{{ route('admin.divisi.destroy', $item->id) }}" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus divisi {{ $item->divisi_name }}? Tindakan ini tidak dapat dibatalkan.')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit"
                                                class="text-[#d32f2f] hover:text-[#b71c1c] p-2 rounded-full hover:bg-red-50 transition-colors" title="Hapus">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="px-6 py-8 text-center">
                                <div class="flex flex-col items-center justify-center text-gray-400">
                                    <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-3">
                                        <i class="fas fa-school text-gray-300 text-2xl"></i>
                                    </div>
                                    <p class="text-lg font-medium text-gray-600">Tidak ada data divisi</p>
                                    <p class="text-sm mt-1 text-gray-500">Klik "Tambah Divisi" untuk menambahkan data baru</p>
                                    <button onclick="openModal()" class="mt-3 text-[#2e7d32] hover:text-[#1b5e20] font-medium">
                                        Tambah Divisi
                                    </button>
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <!-- Custom Pagination -->
        <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between px-6 py-4 bg-[#f9fafb] border-t border-gray-200"">
            <div>
                <p class="text-sm text-gray-700 ">
                    Showing <span class="font-medium">{{ $divisi->firstItem() }}</span>
                    to <span class="font-medium">{{ $divisi->lastItem() }}</span>
                    of <span class="font-medium">{{ $divisi->total() }}</span> results
                </p>
            </div>
            <div>
                <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                    {{-- Tombol Previous --}}
                    @if ($divisi->onFirstPage())
                        <span
                            class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-gray-100 text-sm font-medium text-gray-500 dark:text-gray-400">
                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                                viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                                    clip-rule="evenodd" />
                            </svg>
                        </span>
                    @else
                        <a href="{{ $divisi->previousPageUrl() }}"
                            class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 ">
                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                                viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z"
                                    clip-rule="evenodd" />
                            </svg>
                        </a>
                    @endif
                    {{-- Nomor Halaman dengan Ellipses --}}
                    @php
                        $currentPage = $divisi->currentPage();
                        $lastPage = $divisi->lastPage();
                        $start = max($currentPage - 2, 1);
                        $end = min($currentPage + 2, $lastPage);
                    @endphp
                    {{-- Halaman pertama --}}
                    @if ($start > 1)
                        <a href="{{ $divisi->url(1) }}"
                            class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium {{ $currentPage == 1 ? 'bg-[#2e7d32] text-white' : 'bg-white text-gray-500 hover:bg-gray-50 ' }}">
                            1
                        </a>
                        @if ($start > 2)
                            <span
                                class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-gray-100 text-sm font-medium text-gray-500 dark:text-gray-400">…</span>
                        @endif
                    @endif
                    {{-- Halaman di sekitar current --}}
                    @for ($page = $start; $page <= $end; $page++)
                        @if ($page == $currentPage)
                            <span
                                class="z-10 bg-success-50 dark:bg-[#1b5e20] border-[#2e7d32] text-[#1b5e20] dark:text-white relative inline-flex items-center px-4 py-2 border text-sm font-medium">
                                {{ $page }}
                            </span>
                        @else
                            <a href="{{ $divisi->url($page) }}"
                                class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 relative inline-flex items-center px-4 py-2 border text-sm font-medium">
                                {{ $page }}
                            </a>
                        @endif
                    @endfor
                    {{-- Halaman terakhir --}}
                    @if ($end < $lastPage)
                        @if ($end < $lastPage - 1)
                            <span
                                class="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-gray-100 text-sm font-medium text-gray-500 dark:text-gray-400">…</span>
                        @endif
                        <a href="{{ $divisi->url($lastPage) }}"
                            class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium {{ $currentPage == $lastPage ? 'bg-[#2e7d32] text-white' : 'bg-white text-gray-500 hover:bg-gray-50 ' }}">
                            {{ $lastPage }}
                        </a>
                    @endif
                    {{-- Tombol Next --}}
                    @if ($divisi->hasMorePages())
                        <a href="{{ $divisi->nextPageUrl() }}"
                            class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 ">
                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                                viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                    clip-rule="evenodd" />
                            </svg>
                        </a>
                    @else
                        <span
                            class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-gray-100 text-sm font-medium text-gray-500 dark:text-gray-400">
                            <svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                                viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"
                                    clip-rule="evenodd" />
                            </svg>
                        </span>
                    @endif
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- Modal Tambah/Edit Divisi -->
<div id="divisiModal" class="fixed inset-0 bg-black/40 hidden z-50 flex items-center justify-center p-4" onclick="closeModal()">
    <div class="bg-white rounded-lg max-w-md w-full mx-auto shadow-xl transform transition-all" onclick="event.stopPropagation()">
        <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-3">
                    <i class="fas fa-school text-green-600"></i>
                </div>
                <h3 class="text-lg font-medium text-[#1a472a]" id="modalTitle">
                    Tambah Divisi Baru
                </h3>
            </div>
        </div>
       
        <div class="px-6 py-4">
            <form id="divisiForm" action="{{ route('admin.divisi.store') }}" method="POST" class="space-y-4">
                @csrf
                <!-- Nama Divisi -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nama Divisi <span class="text-red-500">*</span></label>
                    <input type="text" name="divisi" id="divisiInput" required
                        class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#2e7d32] focus:border-[#2e7d32] transition-colors"
                        placeholder="Contoh: Information Technology" required>
                </div>
                <!-- Warna Cover -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Warna Cover</label>
                    <div class="flex flex-col sm:flex-row sm:items-center gap-3">
                        <!-- Color Picker -->
                        <input type="color" id="colorPicker"
                            class="w-full sm:w-14 h-14 p-1 border border-gray-300 rounded-md cursor-pointer" value="#2e7d32">
                        <!-- HEX Value -->
                        <input type="text" name="cover_color" id="colorHex"
                            class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#2e7d32] focus:border-[#2e7d32] transition-colors"
                            placeholder="#2e7d32">
                    </div>
                </div>
            </form>
        </div>
       
        <div class="px-6 py-4 bg-gray-50 flex justify-end space-x-3">
            <button type="button" onclick="closeModal()"
                    class="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-100 transition-colors">
                Batal
            </button>
            <button type="submit" form="divisiForm"
                    class="px-4 py-2 bg-[#2e7d32] text-white rounded-md hover:bg-[#1b5e20] transition-colors flex items-center">
                <i class="fas fa-save mr-2"></i>
                Simpan
            </button>
        </div>
    </div>
</div>
@endsection
@push('styles')
<style>
    /* Responsive adjustments */
    @media (max-width: 640px) {
        .flex-wrap {
            justify-content: center;
        }
    }
   
    /* Custom scrollbar for table */
    .overflow-x-auto::-webkit-scrollbar {
        height: 6px;
    }
   
    .overflow-x-auto::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }
   
    .overflow-x-auto::-webkit-scrollbar-thumb {
        background: #c1c1c1;
        border-radius: 10px;
    }
   
    .overflow-x-auto::-webkit-scrollbar-thumb:hover {
        background: #a8a8a8;
    }
   
    /* Smooth transitions */
    .transition-colors {
        transition: color 0.2s ease, background-color 0.2s ease;
    }
   
    .transition-shadow {
        transition: box-shadow 0.2s ease;
    }
</style>
@endpush
@push('scripts')
<script>
    const picker = document.getElementById('colorPicker');
    const hexInput = document.getElementById('colorHex');
   
    // Set default HEX saat load
    hexInput.value = picker.value;
   
    // Update HEX setiap warna berubah (picker to hex)
    picker.addEventListener('input', () => {
        hexInput.value = picker.value;
    });

    // Update picker jika HEX diubah manual (hex to picker, jika valid)
    hexInput.addEventListener('input', () => {
        const hex = hexInput.value.trim();
        if (/^#[0-9A-Fa-f]{6}$/.test(hex)) {
            picker.value = hex;
        }
    });
   
    function openModal() {
        // Remove existing _method if any
        let existingMethod = document.querySelector('#divisiForm input[name="_method"]');
        if (existingMethod) {
            existingMethod.remove();
        }
        // Reset fields
        document.getElementById('divisiModal').classList.remove('hidden');
        document.getElementById('modalTitle').textContent = 'Tambah Divisi Baru';
        document.getElementById('divisiForm').action = '{{ route("admin.divisi.store") }}';
        document.getElementById('divisiForm').method = 'POST';
        document.getElementById('divisiInput').value = '';
        // Reset color to default
        document.getElementById('colorPicker').value = '#2e7d32';
        document.getElementById('colorHex').value = '#2e7d32';
    }
   
    function closeModal() {
        document.getElementById('divisiModal').classList.add('hidden');
    }
   
    function editDivisi(divisi) {
        // Remove existing _method if any, then add PUT
        let existingMethod = document.querySelector('#divisiForm input[name="_method"]');
        if (existingMethod) {
            existingMethod.value = 'PUT';
        } else {
            let methodInput = document.createElement('input');
            methodInput.type = 'hidden';
            methodInput.name = '_method';
            methodInput.value = 'PUT';
            document.getElementById('divisiForm').appendChild(methodInput);
        }
        // Set fields
        document.getElementById('divisiModal').classList.remove('hidden');
        document.getElementById('modalTitle').textContent = 'Edit Divisi';
        document.getElementById('divisiForm').action = '{{ route("admin.divisi.update", ":id") }}'.replace(':id', divisi.id);
        document.getElementById('divisiForm').method = 'POST';
        document.getElementById('divisiInput').value = divisi.divisi_name;
        document.getElementById('colorPicker').value = divisi.color_cover;
        document.getElementById('colorHex').value = divisi.color_cover;
    }
   
    // Close modal on Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            closeModal();
        }
    });
</script>
@endpush