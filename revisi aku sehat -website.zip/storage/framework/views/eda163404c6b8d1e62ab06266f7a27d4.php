<?php $__env->startSection('title', 'Edit Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-4 md:space-y-6">
    <div class="flex items-center gap-2 md:gap-3">
        <a href="<?php echo e(route('admin.users.index')); ?>" class="text-gray-600 hover:text-gray-900 p-1 md:p-0">
            <i class="fas fa-arrow-left text-sm md:text-base"></i>
        </a>
        <div>
            <h2 class="text-xl md:text-2xl font-bold text-gray-900">Edit Data Users</h2>
            <p class="text-xs md:text-sm text-gray-600">Perbarui data users</p>
        </div>
    </div>

    <div class="bg-white shadow-sm rounded-lg">
        <form action="<?php echo e(route('admin.users.update', $member->id)); ?>" method="POST" class="p-4 md:p-6 space-y-4 md:space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                <div>
                    <label class="block text-xs md:text-sm font-medium text-gray-700 mb-1.5 md:mb-2">
                        Nomor Induk <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="nomor_induk" value="<?php echo e(old('nomor_induk', $member->nomor_induk)); ?>" required
                           class="w-full text-sm md:text-base border border-gray-300 rounded-md px-3 py-3.5 md:py-2 focus:outline-none focus:ring-2 focus:ring-[#2e7d32]"
                           placeholder="Contoh: 001234">
                    <?php $__errorArgs = ['nomor_induk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="block text-xs md:text-sm font-medium text-gray-700 mb-1.5 md:mb-2">
                        Nama Lengkap <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="nama" value="<?php echo e(old('nama', $member->nama)); ?>" required
                           class="w-full text-sm md:text-base border border-gray-300 rounded-md px-3 py-3.5 md:py-2 focus:outline-none focus:ring-2 focus:ring-[#2e7d32]">
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="block text-xs md:text-sm font-medium text-gray-700 mb-1.5 md:mb-2">
                        Username <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="username" value="<?php echo e(old('username', $member->username)); ?>" required
                           class="w-full text-sm md:text-base border border-gray-300 rounded-md px-3 py-3.5 md:py-2 focus:outline-none focus:ring-2 focus:ring-[#2e7d32]">
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="block text-xs md:text-sm font-medium text-gray-700 mb-1.5 md:mb-2">
                        Password Baru <span class="text-xs text-gray-500">(Kosongkan jika tidak ingin mengubah)</span>
                    </label>
                    <input type="password" name="password"
                           class="w-full text-sm md:text-base border border-gray-300 rounded-md px-3 py-3.5 md:py-2 focus:outline-none focus:ring-2 focus:ring-[#2e7d32]"
                           placeholder="Minimal 6 karakter">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="block text-xs md:text-sm font-medium text-gray-700 mb-1.5 md:mb-2">
                        Divisi
                    </label>
                    <select id="divisi-select" name="id_divisi"
                            class="w-full text-sm md:text-base border border-gray-300 rounded-md px-3 py-1.5 md:py-2 focus:outline-none focus:ring-2 focus:ring-[#2e7d32]">
                        <option value="">Pilih Divisi</option>
                        <?php $__currentLoopData = $divisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>" <?php echo e(old('id_divisi', $member->id_divisi) == $k->id ? 'selected' : ''); ?>>
                                <?php echo e($k->divisi_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_divisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label class="block text-xs md:text-sm font-medium text-gray-700 mb-1.5 md:mb-2">
                        Peran
                    </label>
                    <select id="peran-select" name="level"
                            class="w-full text-sm md:text-base border border-gray-300 rounded-md px-3 py-1.5 md:py-2 focus:outline-none focus:ring-2 focus:ring-[#2e7d32]">
                        <option value="">Pilih Peran</option>
                        <option value="Admin" <?php echo e(old('level', $member->level) == 'Admin' ? 'selected' : ''); ?>>
                            Admin
                        </option>
                        <option value="Health Consultant" <?php echo e(old('level', $member->level) == 'Health Consultant' ? 'selected' : ''); ?>>
                            Health Consultant
                        </option>
                        <option value="Health Monitor" <?php echo e(old('level', $member->level) == 'Health Monitor' ? 'selected' : ''); ?>>
                            Health Monitor
                        </option>
                        <option value="Member" <?php echo e(old('level', $member->level) == 'Member' ? 'selected' : ''); ?>>
                            Member
                        </option>
                    </select>
                    <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div>
                <label class="block text-xs md:text-sm font-medium text-gray-700 mb-2">
                    Jenis Kelamin <span class="text-red-500">*</span>
                </label>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <!-- Laki-laki -->
                    <label 
                        class="flex items-center gap-3 p-3 border rounded-lg cursor-pointer transition
                            hover:bg-green-50
                            <?php echo e(old('jk') == 'L' ? 'border-green-600 bg-green-50' : 'border-gray-300'); ?>">
                        <input
                            type="radio"
                            name="jk"
                            value="L"
                            required
                            class="h-7 w-5 text-green-700 focus:ring-green-600"
                            <?php echo e(old('jk', $member->jk) == 'L' ? 'checked' : ''); ?>>
                        <span class="text-sm md:text-base font-medium">Laki-laki</span>
                    </label>
                    <!-- Perempuan -->
                    <label 
                        class="flex items-center gap-3 p-3 border rounded-lg cursor-pointer transition
                            hover:bg-green-50
                            <?php echo e(old('jk') == 'P' ? 'border-green-600 bg-green-50' : 'border-gray-300'); ?>">
                        <input
                            type="radio"
                            name="jk"
                            value="P"
                            required
                            class="h-7 w-5 text-green-700 focus:ring-green-600"
                            <?php echo e(old('jk', $member->jk) == 'P' ? 'checked' : ''); ?>>
                        <span class="text-sm md:text-base font-medium">Perempuan</span>
                    </label>
                </div>
                <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Stats Info -->
            <div class="bg-yellow-50 p-3 md:p-4 rounded-md">
                <div class="flex gap-2 md:gap-3">
                    <div class="flex-shrink-0">
                        <i class="fas fa-info-circle text-yellow-400 text-sm md:text-base"></i>
                    </div>
                    <div>
                        <h3 class="text-xs md:text-sm font-medium text-yellow-800 mb-1 md:mb-2">Statistik Users</h3>
                        <div class="text-xs md:text-sm text-yellow-700 space-y-0.5 md:space-y-1">
                            <p>• Data Kesehatan: <span class="font-medium"><?php echo e($member->kesehatan->count()); ?> data</span></p>
                            <p>• Data HB: <span class="font-medium"><?php echo e($member->hb->count()); ?> data</span></p>
                            <p>• Terdaftar sejak: <span class="font-medium"><?php echo e($member->created_at->format('d/m/Y')); ?></span></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex flex-col-reverse sm:flex-row justify-end gap-2 md:gap-3 pt-4 md:pt-6">
                <a href="<?php echo e(route('admin.users.index')); ?>" 
                   class="w-full sm:w-auto px-4 py-2 text-xs md:text-sm border border-gray-300 rounded-md text-center text-gray-700 hover:bg-gray-50 transition-colors">
                    Batal
                </a>
                <button type="submit" 
                        class="w-full sm:w-auto px-4 py-2 text-xs md:text-sm bg-[#2e7d32] text-white rounded-md hover:bg-[#1b5e20] transition-colors">
                    <i class="fas fa-save mr-1.5 text-xs"></i>
                    Update Data
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new TomSelect("#divisi-select", {
            placeholder: "Cari divisi...",
            allowEmptyOption: true,
            maxOptions: 1000,
        });

        new TomSelect("#peran-select", {
            placeholder: "Cari peran...",
            allowEmptyOption: true,
            maxOptions: 1000,
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\VS Code\Jurnal\versifix\AkuSehat\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>