<?php $__env->startSection('title', 'Edit Data HB'); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-6">
        <div class="bg-white p-8 rounded-lg shadow-sm">
            <h2 class="text-2xl font-bold text-gray-900">Edit Data Hemoglobin (HB)</h2>
            <p class="text-gray-600">Perbarui data kadar hemoglobin member</p>
        </div>

        <div class="bg-white shadow-sm rounded-lg">
            <form action="<?php echo e(route('admin.hb.update', $hb->id_hb)); ?>" method="POST" class="p-6 space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="member-select" class="block text-sm font-medium text-gray-700 mb-2">Member</label>
                        <select id="member-select" name="id_user" required disabled
                            class="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#007acc]">
                            <option value="">Pilih Member</option>
                            <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->id); ?>"
                                    <?php echo e(old('id_user', $hb->id_user) == $s->id ? 'selected' : ''); ?>>
                                    <?php echo e($s->level ?? '-'); ?> •
                                    <?php echo e($s->divisi->divisi_name ?? '-'); ?> • 
                                    <?php echo e($s->nama); ?> (<?php echo e($s->nomor_induk); ?>) •
                                    <?php echo e($s->jk === 'L' ? 'Laki-laki' : 'Perempuan'); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['id_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Kadar HB (g/dL)
                        </label>
                        <input type="number" step="0.1" name="hb" value="<?php echo e(old('hb', $hb->hb)); ?>" required
                            class="w-full border border-gray-300 rounded-md px-3 py-3.5 focus:outline-none focus:ring-2 focus:ring-[#007acc]"
                            placeholder="Contoh: 12.5" min="0" max="25">
                        <?php $__errorArgs = ['hb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="bg-yellow-50 p-4 rounded-md">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-exclamation-triangle text-yellow-400"></i>
                        </div>
                        <div class="ml-3">
                            <h3 class="text-sm font-medium text-yellow-800">Status Saat Ini</h3>
                            <div class="mt-2 text-sm text-yellow-700">
                                <p><strong>HB:</strong> <?php echo e($hb->hb); ?> g/dL</p>
                                <p><strong>Status:</strong> <?php echo e($hb->status); ?></p>
                                <p><strong>Pesan:</strong> <?php echo e($hb->pesan); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bg-blue-50 p-4 rounded-md">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-info-circle text-blue-400"></i>
                        </div>
                        <div class="ml-3">
                            <h3 class="text-sm font-medium text-blue-800">Referensi Kadar HB Normal</h3>
                            <div class="mt-2 text-sm text-blue-700">
                                <ul class="list-disc list-inside">
                                    <li><strong>Laki-laki:</strong> 13.0 - 17.0 g/dL</li>
                                    <li><strong>Perempuan:</strong> 12.0 - 15.0 g/dL</li>
                                    <li><strong>Anemia:</strong> Di bawah nilai normal</li>
                                    <li><strong>Tinggi:</strong> Di atas nilai normal</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end space-x-3 pt-6">
                    <a href="<?php echo e(route('admin.hb.index')); ?>"
                        class="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition-colors">
                        Batal
                    </a>
                    <button type="submit"
                        class="px-4 py-2 bg-[#308a34] text-white rounded-md hover:bg-[#1B5E20] transition-colors">
                        <i class="fas fa-save mr-2"></i>
                        Update Data HB
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new TomSelect("#member-select", {
            placeholder: "Cari member...",
            allowEmptyOption: true,
            maxOptions: 1000,
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\VS Code\Jurnal\versifix\AkuSehat\resources\views/admin/hb/edit.blade.php ENDPATH**/ ?>