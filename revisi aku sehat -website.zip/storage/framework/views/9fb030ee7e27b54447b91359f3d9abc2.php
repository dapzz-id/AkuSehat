<?php $__env->startSection('title', 'Tambah Data Kesehatan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-6">
        <div class="bg-white p-8 rounded-lg shadow-sm">
            <h2 class="text-2xl font-bold text-gray-900">Tambah Data Kesehatan</h2>
            <p class="text-gray-600">Masukkan data kesehatan member</p>
        </div>

        <div class="bg-white shadow-sm rounded-lg">
            <form action="<?php echo e(route('admin.kesehatan.store')); ?>" method="POST" class="p-6 space-y-6">
                <?php echo csrf_field(); ?>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="member-select" class="block text-sm font-medium text-gray-700 mb-2">Member</label>
                        <select id="member-select" name="id_user" required
                            class="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-[#007acc]">
                            <option value="">Pilih Member</option>
                            <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->id); ?>" <?php echo e(old('id_user') == $s->id ? 'selected' : ''); ?>>
                                    <?php echo e($s->divisi->divisi_name ?? '-'); ?> • 
                                    <?php echo e($s->nama); ?> (<?php echo e($s->nomor_induk); ?>) • 
                                    <?php echo e($s->jk === 'L' ? 'Laki-laki' : 'Perempuan'); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['id_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Berat Badan (kg)</label>
                        <input type="number" step="0.1" name="bb" value="<?php echo e(old('bb')); ?>" required
                            class="w-full border border-gray-300 rounded-md px-3 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Contoh: 60.5">
                        <?php $__errorArgs = ['bb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Tinggi Badan (cm)</label>
                        <input type="number" name="tb" value="<?php echo e(old('tb')); ?>" required
                            class="w-full border border-gray-300 rounded-md px-3 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Contoh: 165">
                        <?php $__errorArgs = ['tb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Sistol (mmHg)</label>
                        <input type="number" name="sistol" value="<?php echo e(old('sistol')); ?>" required
                            class="w-full border border-gray-300 rounded-md px-3 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Contoh: 120">
                        <?php $__errorArgs = ['sistol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Diastol (mmHg)</label>
                        <input type="number" name="diastol" value="<?php echo e(old('diastol')); ?>" required
                            class="w-full border border-gray-300 rounded-md px-3 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Contoh: 80">
                        <?php $__errorArgs = ['diastol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Kondisi Telinga</label>
                        <input type="text" name="kondisi_telinga" value="<?php echo e(old('kondisi_telinga')); ?>"
                            class="w-full border border-gray-300 rounded-md px-3 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Normal / Ada gangguan (kosongkan jika tidak ada)">
                        <?php $__errorArgs = ['kondisi_telinga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Kondisi Gigi</label>
                        <input type="text" name="kondisi_gigi" value="<?php echo e(old('kondisi_gigi')); ?>"
                            class="w-full border border-gray-300 rounded-md px-3 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Sehat / Ada karies / dll (kosongkan jika tidak ada)">
                        <?php $__errorArgs = ['kondisi_gigi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Perilaku Beresiko</label>
                        <input name="perilaku_beresiko"
                            class="w-full border border-gray-300 rounded-md px-3 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Merokok, alkohol, dll (kosongkan jika tidak ada)"><?php echo e(old('perilaku_beresiko')); ?></input>
                        <?php $__errorArgs = ['perilaku_beresiko'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="grid grid-cols-1 gap-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Gangguan Reproduksi</label>
                        <textarea name="gangguan_reproduksi" rows="3"
                            class="w-full border border-gray-300 rounded-md px-3 py-3.5 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Gangguan menstruasi, dll (kosongkan jika tidak ada)"><?php echo e(old('gangguan_reproduksi')); ?></textarea>
                        <?php $__errorArgs = ['gangguan_reproduksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="flex justify-end space-x-3 pt-6">
                    <a href="<?php echo e(route('admin.kesehatan.index')); ?>"
                        class="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition-colors">
                        Batal
                    </a>
                    <button type="submit"
                        class="px-4 py-2 bg-[#308a34] text-white rounded-md hover:bg-[#1B5E20] transition-colors">
                        <i class="fas fa-save mr-2"></i>
                        Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        new TomSelect("#member-select", {
            placeholder: "Cari member...",
            allowEmptyOption: true,
            maxOptions: 1000,
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\VS Code\Jurnal\versifix\AkuSehat\resources\views/admin/kesehatan/create.blade.php ENDPATH**/ ?>